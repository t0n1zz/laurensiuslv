@extends('_layouts.public')

@section('content')
<div class="col-sm-12">
   <div class="media">
      <span class="pull-left">
        {{ HTML::image('images/jetassault.png', 'JetAssault Logo', array('class' => 'img-rounded','width' => '100')) }}
      </span>
      <div class="media-body">
        <hr />
        <h1 class="media-heading">JetAssault <small>Version 2.1</small></h1>
      </div>
   </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Be ready to navigate high tech jet to save the earth and destroy as many as alien jet that you can destroy
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <h4>Jet Assault is a arcade shooter game where player will control high tech alien jet with touching screen using fingger or using accelerometer input to fight against alien jet that trying to invade earth.</h4>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Main Features
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <ul>
        <li>Drive high tech jet with your finger or using accelerometer</li>
        <li>Upgradeable health and projectile level</li>
        <li>Upgradeable special weapon and shield</li>
        <li>One against hundred of alien jets</li>
        <li>Many challenging level</li>
    </ul>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Screenshots
  </div>
</div>

<div class="col-sm-12" >
    {{ HTML::image('images/jetassault-screenshoot1.png', 'Screenshots 1', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot2.png', 'Screenshots 2', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot3.png', 'Screenshots 3', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot4.png', 'Screenshots 4', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot5.png', 'Screenshots 5', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot6.png', 'Screenshots 6', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot7.png', 'Screenshots 7', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassault-screenshoot8.png', 'Screenshots 8', array('class' => 'img-thumbnail','width' => '400')) }}
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Videos
  </div>
</div>

<div class="col-sm-12">
    <iframe width="400" height="300" src="//www.youtube.com/embed/5sNPag59PPM?list=UUP57_h23LP5VCFW4Jfj5axg" frameborder="0" allowfullscreen></iframe>
    <iframe width="400" height="300" src="//www.youtube.com/embed/lJ5sEn9xVWk?list=UUP57_h23LP5VCFW4Jfj5axg" frameborder="0" allowfullscreen></iframe>
    <iframe width="800" height="400" src="//www.youtube.com/embed/Dvpfcf1w9gc?list=UUP57_h23LP5VCFW4Jfj5axg" frameborder="0" allowfullscreen></iframe>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Download
  </div>
</div>

<div class="col-sm-12">
  <a href="http://www.windowsphone.com/en-gb/store/app/jetassault/3e03678f-5d29-4196-8860-843c04fae817"
     target="_blank">{{ HTML::image('images/wp_store.png"','WP Store Links', array('class' => 'img-responsive')) }}</a>
  <br />
  {{ HTML::image('images/jetassaultQR.jpg', 'Download QR Code', array('class' => 'img-responsive')) }}
</div>

<div class="col-sm-12">
    <div class="page-header text-muted divider">
        Updates
    </div>
</div>
@if(!empty($posts))
    <div class="col-sm-12">
        <ul>
        @foreach($posts as $post)
            <li>{{ link_to_route('post', $post->judul, array($post->id)) }}</li>
        @endforeach
        </ul>
    </div>
@else
    <div class="col-sm-12">
        <ul>
            <li>No update yet...</li>
        </ul>
    </div>
@endif

@stop