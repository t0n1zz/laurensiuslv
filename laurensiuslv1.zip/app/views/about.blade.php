@extends('_layouts.public')

@section('content')
<div class="col-sm-9">
  <h1>Laurensius Tony <br/
    ><small><blockquote>Publication IT, Unity3D Game Developer & Windows Phone Developer</blockquote></small></h1>
  <div class="page-header text-muted divider">
    <h3>5 Facts About Me</h3>
  </div>
</div>

<div class="col-sm-3">
  <img src="{{ asset('images/me.jpg') }}" class="img-rounded" width="200" >
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-red set-icon">
        1
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Born in Pontianak, Indonesia July 1992</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-yellow set-icon">
        2
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Like to learn and find new things</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-green set-icon">
        3
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Cat Lover</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-brown set-icon">
        4
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Tech Savvy</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-blue set-icon">
        5
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Catholic</h3>
      </div>
    </div>
  </div>
</div>

<!--education-->
<div class="col-sm-12">
  <div class="page-header text-muted divider">
    Education History
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-blue set-icon">
        <i class="fa fa-graduation-cap"></i>
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Widya Dharma College
        <small>2010 - 2014</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-brown set-icon">
        <i class="fa fa-book"></i>
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Gembala Baik Senior High School
        <small>2007 - 2010</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-green set-icon">
        <i class="fa fa-bus"></i>
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Gembala Baik Junior High School
        <small>2004 - 2007</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-red set-icon">
        <i class="fa fa-futbol-o"></i>
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Gembala Baik Elementary School
        <small>1998 - 2004</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box bg-color-yellow set-icon">
        <i class="fa fa-pencil"></i>
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Gembala Baik Kindergarden
        <small>1996 - 1998</small></h3>
      </div>
    </div>
  </div>
</div>
<!--/education-->

<!--skills-->
<div class="col-sm-12">
  <div class="page-header text-muted divider">
    Know How To Use
  </div>
</div>


<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/psd.jpg') }}" alt="Photoshop" class="img-thumbnail" >
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Adobe Photoshop</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/ai.jpg') }}" alt="Illustrator" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Adobe Illustrator</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/proshow.jpg') }}" alt="Proshow Producer" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Proshow Producer</h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/unity.jpg') }}" alt="Unity3D" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Unity3D <small>C#</small> </h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/wp.jpg') }}" alt="Windows Phone Development" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Windows Phone Development <small>C# and XAML</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/php.jpg') }}" alt="PHP & MYSQL" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">PHP & MYSQL Database <small>PHP5.x</small></h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/bootstrap.jpg') }}" alt="Bootstrap" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Bootstrap <small>HTML5, CSS3, JS</small> </h3>
      </div>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="icon-box ">
        <img src="{{ asset('images/laravel.png') }}" alt="laravel" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Laravel <small>The PHP Framework For Web Artisans</small> </h3>
      </div>
    </div>
  </div>
</div>
<!--/skills-->

<!--other-->
<div class="col-sm-12">
  <div class="page-header text-muted divider">
    Other
  </div>
</div>

<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="pull-left">
        <img src="{{ asset('images/lumiaappsolympiad.jpg') }}" alt="Bootstrap" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">3rd Place LumiaAppOlympiad <br/><small
        ><span class="fa fa-calendar-o"></span> 18 December 2012</small><br /
        ><small><a href="http://nice.or.id/niceevents/2012/12/18/inilah-pemenang-lumia-apps-olympiad/"
        target="_blank"><span class="fa fa-external-link"></span> Website</small></h3>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-sm-12">
    <div class="media">
      <span class="pull-left">
        <img src="{{ asset('images/bizspark_startup.jpg') }}" alt="Bootstrap" class="img-thumbnail">
      </span>
      <div class="media-body">
        <hr/>
        <h3 class="media-heading">Member Of BizSpark Startup <br/><small
        ><span class="fa fa-calendar-o"></span> 11 December 2013</small><br /
        ><small><a href="https://www.microsoft.com/bizspark/startup/profile.aspx?startup=281888"
        target="_blank"><span class="fa fa-external-link"></span> Website (only visible to BizSpark members)</small></h3>
      </div>
    </div>
  </div>
</div>
<!--/other-->

@stop