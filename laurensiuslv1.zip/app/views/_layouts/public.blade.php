<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>Laurensius</title>
        <link rel="shortcut icon" href="{{ asset('images/logo.png') }}">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		{{ HTML::style('css/bootstrap.min.css') }}
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		{{ HTML::style('css/styles.css') }}

        <!-- Custom Fonts -->
         {{ HTML::style('plugins/font-awesome-4.2.0/css/font-awesome.min.css') }}
	</head>
	<body>
<div class="wrapper">
    <div class="box">
        <div class="row">
            <!-- sidebar -->
            @include('_layouts.sidebar')
            <!-- /sidebar -->

            <!-- main -->
            <div class="column col-sm-9" id="main" style="opacity: 0.9;">
                <div class="padding">
                    <div class="full col-sm-9">

                    @yield('content')

                    <!-- footer -->
                    @include('_layouts.footer')
                    <hr>
                    </div><!-- /col-9 -->
                </div><!-- /padding -->
            </div>
            <!-- /main -->

        </div>
    </div>
</div>
	<!-- script references -->
		<script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.2/jquery.min.js"></script>
		{{ HTML::script('js/bootstrap.min.js') }}
	</body>
</html>