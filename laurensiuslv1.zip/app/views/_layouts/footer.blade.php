<div class="col-sm-12">
  <div class="page-header text-muted divider">
    Connect with Me
  </div>
</div>

<div class="row">
  <div class="col-sm-6">
    <a href="https://twitter.com/t0n1zz" target="_blank">Twitter</a> <small class="text-muted">|</small> <a 
       href="https://www.facebook.com/tony.doangzz" target="_blank">Facebook</a> <small class="text-muted">|</small> <a 
       href="https://plus.google.com/u/0/108100311371354375575" target="_blank">Google+</a>
  </div>
</div>