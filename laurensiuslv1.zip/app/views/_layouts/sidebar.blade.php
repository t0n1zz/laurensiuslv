<div class="column col-sm-3" id="sidebar">
    {{ link_to_route('home', 'Ls',null,array('class'=>'logo')) }}
    <ul class="nav">
        <li >
          {{ link_to_route('home', 'Blog') }}
        </li>
        <li>
          {{ link_to_route('creation', 'Creation') }}
          <ul>
            <li>{{ link_to_route('jetassault', 'JetAssault') }}</li>
            <li>{{ link_to_route('jetassaultgatekeeper', 'JetAssault:Gatekeeper') }}</li>
            <li>{{ link_to_route('myworld', 'MYWorld') }}</li>
          </ul>
        </li>
        <li>
            {{ link_to_route('about', 'About Me') }}
        </li>
        <li>
            <div class="row">
            <div class="col-sm-12">
            {{ Form::open(array('route' => array('search'))) }}
                <div class="input-group">
                    {{ Form::text('searchkey',null,array('class' => 'form-control', 'placeholder' => 'Search the blog'))}}
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
                     </span>
                </div>
            {{ Form::close() }}
            </div>
            </div>
        </li>
    </ul>
    <ul class="nav hidden-xs" id="sidebar-footer">
        <li>
          <a ><h3>Laurensius</h3></a>
        </li>
    </ul>
</div>