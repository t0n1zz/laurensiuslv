<div class="panel panel-default">
<!--button-->
<div class="panel-heading tooltip-demo">
	<button type="submit" name="simpan" class="btn btn-primary" data-toggle ='tooltip' 
	    data-placement='top' title ='Menyimpan artikel' value="simpan">Simpan</button>

	<button type="submit" name="batal" class="btn btn-default" data-toggle ='tooltip'
	    data-placement='top' title ='Batal menyimpan artikel dan kembali ke halaman kelola artikel' value="batal">Batal</button>
	<!--<a href="{{ URL::previous() }}" class="btn btn-default">Batal</a>-->
</div>
<!--/button-->
<div class="panel-body">
    <!--judul-->
    <div class="col-lg-10">
    <div class="form-group">
        {{ Form::label('Judul Artikel') }}
        {{ Form::text('judul',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan judul artikel'))}}
        {{ $errors->first('judul', '<p class="text-warning"><i>:message</i></p>') }}
    </div>
    </div>
    <!--/judul-->
    <!--kategori-->
    <div class="col-lg-4">
    <div class="form-group">
        {{ Form::label('Kategori') }}
        <select class="form-control" onChange="changeFunc(value);" name="kategori">
        	<option >Pilih Kategori Artikel</option>\
            @foreach($kategori_artikel as $kategoriartikel)
				<option value="{{ $kategoriartikel->id }}" 
				@if(!empty($artikel))
					@if($artikel->kategori == $kategoriartikel->id)
						{{ "selected" }}
					@endif
				@endif
				>{{ $kategoriartikel->name }}</option>
            @endforeach
        	<option value="tambah" >Tambah Kategori Baru</option>
        </select>
    </div>
    </div>
    <!--/kategori-->
    <!--kategori baru-->
    <div class="col-lg-4"  id="pilihan" style="display:none;">
    <div class="form-group">
    	{{ Form::label('Kategori Baru') }}
    	{{ Form::text('kategori_baru',null,array('class' => 'form-control', 'placeholder' => 'Silahkan masukkan kategori baru', 
    	   'maxlength' => '30'))}} 
    </div>
    </div>
    <!--/kategori baru-->
    <!--status-->
    <div class="col-lg-4">
    <div class="form-group">
        {{ Form::label('Status') }}
        {{ Form::select('status',array('0' => 'Tidak diterbikan', '1' => 'Terbitkan'),null, array('class' => 'form-control')) }}
    </div>
    </div>
    <!--/status-->
    <!--gambar utama-->
    <div class="col-lg-5">
    <div class="form-group">
        {{ Form::label('Tampilkan Gambar Utama') }}
        <div class="input-group">
        <span class="input-group-addon">
        	@if(!empty($artikel->gambar))
        		{{ Form::checkbox('gambarutama','1',true,array('id' => 'tampilinputgambar')) }}
        	@else 
        		{{ Form::checkbox('gambarutama','1',false,array('id' => 'tampilinputgambar')) }}
        	@endif
        </span>
        @if(!empty($artikel->gambar))
        	{{ Form::text('null','Iya, gambar akan muncul di list artikel dan view artikel',array('class' => 
        	   'form-control', 'id' => 'gambartext' ,'disabled' => 'true'))}} 
        @else
        	{{ Form::text('null','Tidak',array('class' => 'form-control', 'id' => 'gambartext' ,'disabled' => 'true'))}}
        @endif
        </div>
    </div>
    <div id="inputgambar"
    @if(empty($artikel->gambar))
    	{{ "style='display:none;'" }}
    @endif 
    >
        <div class="thumbnail" >
        @if(!empty($artikel->gambar))
        	{{ HTML::image('images_artikel/'.$artikel->gambar, 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar')) }}
        @else 
        	{{ HTML::image('images_artikel/no_image.jpg', 'a picture', array('class' => 'img-responsive', 'id' => 'tampilgambar')) }}
        @endif
             <div class="caption">
                {{ Form::file('gambar', array('onChange' => 'readURL(this)')) }}
             </div>
        </div>
    </div>
    </div>
    <!--/gambar utama-->
    <!--content-->
    <div class="col-lg-12">
        {{ Form::label('Isi Artikel') }}
        {{ Form::textarea('content',null,array('style' => 'height:300px')) }}
        {{ $errors->first('content', '<p class="text-warning"><i>:message</i></p>') }}
    </div>
    <!--/content-->
</div>
</div>