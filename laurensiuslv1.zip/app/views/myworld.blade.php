@extends('_layouts.public')

@section('content')
 <div class="col-sm-12">
   <div class="media">
      <span class="pull-left">
        {{ HTML::image('images/myworld.png', 'JetAssault:Gatekeeper Logo', array('class' => 'img-rounded','width' => '100')) }}
      </span>
      <div class="media-body">
        <hr />
        <h1 class="media-heading">MYWorld <small>Version 1.1.7</small></h1>
      </div>
   </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     MYWorld is an app for discovering places around you and around the world, you can find place to eat, to hang out, public transportation and so on.
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <h4>MYWorld will provide you with complete places information from address to opening hours or a picture or a review from people, that can give you an idea "what's in there", and if you want to go there? </h4>
    <h4>MYWorld provide with a the best navigation suite in windows phone devices with here maps, here drive and here transit.</h4>
    <h4>MYWorld also giving you ability to add your own data about places (address,phone,email,opening hours, etc), so there will be no more outdated information.</h4>
    <h4>And now MYWorld also support discovering event within location powered by eventbrite, so you can discover more interesting thing!</h4>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Main Features
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <ul>
        <li>PView nearby places from pushpin map or augmented reality viewk</li>
        <li>View nearby taken picture from flickr</li>
        <li>View nearby event from eventbrite</li>
        <li>Rich public transportation data powered by here.com</li>
        <li>Navigation powered by here suite</li>
        <li>Add places information powered by windows azure</li>
        <li>Pin to start location or places for quick access</li>
        <li>Recent location and favorite places</li>
        <li>Search location or search nearby places</li>
        <li>Share location or places to social network with elegant picture</li>
    </ul>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Screenshots
  </div>
</div>

<div class="col-sm-12">
    {{ HTML::image('images/myworld-screenshot1.png', 'Screenshots 1', array('class' => 'img-thumbnail','width' => '200')) }}
    {{ HTML::image('images/myworld-screenshot2.png', 'Screenshots 2', array('class' => 'img-thumbnail','width' => '200')) }}
    {{ HTML::image('images/myworld-screenshot3.png', 'Screenshots 3', array('class' => 'img-thumbnail','width' => '200')) }}
    {{ HTML::image('images/myworld-screenshot4.png', 'Screenshots 4', array('class' => 'img-thumbnail','width' => '200')) }}
    {{ HTML::image('images/myworld-screenshot5.png', 'Screenshots 5', array('class' => 'img-thumbnail','width' => '200')) }}
    {{ HTML::image('images/myworld-screenshot6.png', 'Screenshots 6', array('class' => 'img-thumbnail','width' => '200')) }}
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Videos
  </div>
</div>

<div class="col-sm-12">
    <iframe width="800" height="400" src="//www.youtube.com/embed/IRDoMOrHrzA?list=UUP57_h23LP5VCFW4Jfj5axg" frameborder="0" allowfullscreen></iframe>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Download
  </div>
</div>

<div class="col-sm-12">
  <a href="http://www.windowsphone.com/en-gb/store/app/myworld/c49186f5-2161-4875-a3a9-89538a066605"
     target="_blank">{{ HTML::image('images/wp_store.png"','WP Store Links', array('class' => 'img-responsive')) }}</a>
  <br />
  {{ HTML::image('images/myworldQR.png', 'Download QR Code', array('class' => 'img-responsive')) }}
</div>

<div class="col-sm-12">
    <div class="page-header text-muted divider">
        Updates
    </div>
</div>
@if(!empty($posts))
    <div class="col-sm-12">
        <ul>
        @foreach($posts as $post)
            <li>{{ link_to_route('post', $post->judul, array($post->id)) }}</li>
        @endforeach
        </ul>
    </div>
@else
    <div class="col-sm-12">
        <ul>
            <li>No update yet...</li>
        </ul>
    </div>
@endif

@stop