@extends('_layouts.public')

@section('content')

<!--stories-->
<div class="col-sm-12" id="stories">
  <h1>search result for <i>{{ $key }}</i></h1>
</div>
@if($posts->isEmpty())
   <div class="row">
       <div class="col-sm-12">
            <h3>No article found, please try another keywords...</h3>
       </div>
   </div>
@else
    @foreach($posts as $post)
    <div class="row">
        <div class="col-sm-12">
            <h3>{{ link_to_route('post', $post->judul, array($post->id)) }}</h3>
            <blockquote>
                <p>{{{ str_limit(preg_replace('/(<.*?>)|(&.*?;)/', '', $post->content),600) }}}</p>
            </blockquote>
            @if(!is_null($post->kategoriartikel))
            <h4><span class="label label-default">{{ link_to_route('kategori',
                 $post->kategoriartikel->name, array($post->kategoriartikel->id)) }}</span></h4>
            @endif
            <h4><small class="text-muted">{{ $post->created_at->format('l jS \\of F Y h:i:s A') }} • {{ link_to_route('post','Read More', array($post->id)) }}</small></h4>
        </div>
        <div class="row-divider">
            <div class="col-sm-12"><hr></div>
        </div>
    </div>
    @endforeach
@endif
<!--/stories-->

<!-- pagination -->
{{ $posts->links() }}
<!-- /pagination -->

@stop