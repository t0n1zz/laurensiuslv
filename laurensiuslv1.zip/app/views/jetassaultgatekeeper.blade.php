@extends('_layouts.public')

@section('content')
<div class="col-sm-12">
   <div class="media">
      <span class="pull-left">
        {{ HTML::image('images/jetassaultgatekeeper.png', 'JetAssault:Gatekeeper Logo', array('class' => 'img-rounded','width' => '100')) }}
      </span>
      <div class="media-body">
        <hr />
        <h1 class="media-heading">JetAssault:Gatekeeper <small>Version 1.1.1</small></h1>
      </div>
   </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Dive into the world where earth once again being invade by alien and to survive we build a shelter to hide us from them and the only way to enter is by going throught portal gate
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <h4>You once again must protect human race by protecting portal gate from alien attack and destroy every single alien that getting near the gate. You are the last stand, you are the gatekeeper.</h4>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Main Features
  </div>
</div>

<div class="row">
  <div class="col-sm-10">
    <ul>
        <li>Protect the gate from enemy attack</li>
        <li>3 game mode</li>
        <li>Upgradeable part in your jet</li>
        <li>Powerfull powerups</li>
    </ul>
  </div>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Screenshots
  </div>
</div>

<div class="col-sm-12">
    {{ HTML::image('images/jetassaultgatekeeper-screenshot1.png', 'Screenshots 1', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassaultgatekeeper-screenshot2.png', 'Screenshots 2', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassaultgatekeeper-screenshot3.png', 'Screenshots 3', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassaultgatekeeper-screenshot4.png', 'Screenshots 4', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassaultgatekeeper-screenshot5.png', 'Screenshots 5', array('class' => 'img-thumbnail','width' => '400')) }}
    {{ HTML::image('images/jetassaultgatekeeper-screenshot6.png', 'Screenshots 6', array('class' => 'img-thumbnail','width' => '400')) }}
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Videos
  </div>
</div>

<div class="col-sm-12">
    <iframe width="800" height="400" src="//www.youtube.com/embed/qlrrCbWsG1Q?list=UUP57_h23LP5VCFW4Jfj5axg" frameborder="0" allowfullscreen></iframe>
</div>

<div class="col-sm-12">
  <div class="page-header text-muted divider">
     Download
  </div>
</div>

<div class="col-sm-12">
  <a href="http://www.windowsphone.com/en-gb/store/app/jetassault-gatekeeper/1043ab29-32c3-4c4e-ae91-63e20d84417f"
     target="_blank">{{ HTML::image('images/wp_store.png"','WP Store Links', array('class' => 'img-responsive')) }}</a>
  <br />
  {{ HTML::image('images/jetassaultgatekeeperQR.png', 'Download QR Code', array('class' => 'img-responsive')) }}
</div>

<div class="col-sm-12">
    <div class="page-header text-muted divider">
        Updates
    </div>
</div>
@if(!empty($posts))
    <div class="col-sm-12">
        <ul>
        @foreach($posts as $post)
            <li>{{ link_to_route('post', $post->judul, array($post->id)) }}</li>
        @endforeach
        </ul>
    </div>
@else
    <div class="col-sm-12">
        <ul>
            <li>No update yet...</li>
        </ul>
    </div>
@endif

@stop