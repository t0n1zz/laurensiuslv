@extends('_layouts.public')

@section('content')
@if(is_null($post))
    <div class="col-sm-12" id="stories">
       <h3>No article in this category, please check another article...</h3>
    </div>
@else
    <div class="col-sm-12" id="stories">
      <h1><a href="{{ URL::previous() }}"><i class="fa fa-arrow-circle-left"></i></a> {{ $post->judul }}</h1>

      <div class="page-header text-muted divider">
        {{ $post->created_at->format('l jS \\of F Y h:i:s A') }} •  {{ link_to_route('kategori',
           $post->kategoriartikel->name, array($post->kategoriartikel->id)) }}
      </div>
    </div>

    <div class="col-sm-12">
        <blockquote>
            @if(!empty($post->gambar))
                {{ HTML::image('images_artikel/'.$post->gambar, $post->gambar, array('class' => 'img-responsive img-rounded')) }}
            @endif
            <hr>
            {{$post->content}}
        </blockquote>
    </div>
@endif
@stop